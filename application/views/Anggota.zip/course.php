<div style="margin-top:90px; background-color:#F9FAFA;" class="container fixed-top">
            <p>Welcome <br> <b> <?= $biodata->nama ?> </b></p>   
            <div class="container-md-3">
                 <div style="border:none; height:30px; padding-top:6px;  letter-spacing: 2px;" class="alert alert-secondary" role="alert">
                    <label style="font-weight:bold;" class="d-flex align-items-center justify-content-center" >COURSE</label>
                </div>
                <div style="border:none; height:30px; padding-top:6px;  letter-spacing: 2px;" class="alert alert-secondary" role="alert">
                <i class='d-flex align-items-center justify-content-center bx bx-time'> <label style="font-weight:bold;" id="time"></label> </i>
                </div> 
            </div>
        </div>


        
<div style="margin-top:100px; padding-top:40mm; background-color:#F9FAFA;"class="container-md mt-5">
                <div class="row">
                    <div class="container-md-3">
                        <div class="container-md-3 mt-3">
                        <img src="<?= base_url('assets/img/')?>UnderConstruction.gif" width="100%" height="1000%" alt="undercontruction">
                        </div>      
                    </div>
                </div>
</div>