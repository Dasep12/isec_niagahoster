<!-- Content -->
<div style="background-color: #e3e3e1;" class="container-fluid mt-3 pt-5">
              <div class="row">
                <div class="col-md-4 col-6 border border-dark">
                      <div class="card">
                        <div class="card-body">
                        <h5 class="card-title">Pendafaran Anggota Baru</h5>
                        </div>
                      </div>
                </div>       
              </div>
              <div class="row">
                <div class="col-sm-8  border border-dark">                  
                    <div class="card" style="border-radius:15px 15px 15px 15px;">
                        <div class="card-body">
                        <h5 class="card-title">FORM</h5>
                      
                        </div>
                      </div> 
                </div>       
                
                <div class="col-sm-4  border border-dark">
                     <div class="card">
                        <div class="card-body">
                        <h5 class="card-title">Special title treatment</h5>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                        </div>
                      </div> 
                </div> 
              </div>
              <div class="row">
                <div class="col-md-2 col-6 border border-dark">
                1
                </div>       
                <div class="col-md-2 col-6 border border-dark">
                2
                </div>                      
                <div class="col-md-2 col-6 border border-dark">
                3
                </div>
                <div class="col-md-2 col-6 border border-dark">
                 4
                </div>
                <div class="col-md-2 col-6 border border-dark">
               5
                </div>
                <div class="col-md-2 col-6 border border-dark">
               6
                </div>
              </div>
              <div class="row">
                <div class="col-md-2 col-6 border border-dark">
                1
                </div>       
                <div class="col-md-2 col-6 border border-dark">
                2
                </div>                      
                <div class="col-md-2 col-6 border border-dark">
                3
                </div>
                <div class="col-md-2 col-6 border border-dark">
                 4
                </div>
                <div class="col-md-2 col-6 border border-dark">
               5
                </div>
                <div class="col-md-2 col-6 border border-dark">
               6
                </div>
              </div>
              
              <div class="row">
              
                <div class="col-6 col-lg-4 border border-dark">.col-6 .col-lg-4</div>
              </div>   
</div>