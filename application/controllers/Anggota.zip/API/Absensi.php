<?php


require_once(APPPATH.'./libraries/RestController.php');
use chriskacerguis\RestServer\RestController;

date_default_timezone_set('Asia/Jakarta');

class Absensi extends RestController
{
    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->model('Api_Model');
    }

    
    public function cekDataDiri_get(){
        $id = $this->get("id");
        $data = $this->Api_Model->getDataDiriAbsensi($id);
        if ($data->num_rows() > 0) {
            $this->response([
                'status'  => true ,
                'result'  => $data->row()
            ], 200);
        } else {
            $this->response([
                'status' => false,
                'message' => 'data not found '
            ], 404);
        }
    }
    
    public function cekBarcodeKorlap_get()
    {
        # code...
        $wil = $this->get("wilayah");
        $lat = $this->get("latitude");
        $d = $this->db->get_where("barcode_absensi", ['wilayah' => $wil, 'latitude' => $lat]);
        if ($d->num_rows() > 0) {
            $this->response([
                'status'  => true ,
                'message' => 1
            ], 200);
        } else {
            $this->response([
                'status' => false,
                'message' => 0
            ], 404);
        }
    }

    public function cekBarcodeAnggota_get()
    {
        $area = $this->get("area_kerja");
        $lat = $this->get("latitude");
        $d = $this->db->get_where("barcode_absensi", ['area_kerja' => $area, 'latitude' => $lat]);
        if ($d->num_rows() > 0) {
            $this->response([
                'status'  => true ,
                'message' => 1
            ], 200);
        } else {
            $this->response([
                'status' => false,
                'message' => 0
            ], 404);
        }
    }


    //input data absensi ke dalam databasen
    public function inputAbsensi_post(Type $var = null)
    {
        $npk = $this->post("npk");
        $wil = $this->post("wilayah");
        $area = $this->post("area_kerja");
        $id_absen = $this->post("id_absen");
        $now = date('Y-m-d'); //ambil tanggal sekarang

        // $data = [
        //     $wil, $area, $id_absen, $npk
        // ];

        // 


        //tanggal kemarin
        $tgl_kemarin    = date('Y-m-d', strtotime("-1 day", strtotime(date("Y-m-d"))));
        //cek wilayah untuk  penentuan dimana anggota harus di simpan data absennya
        switch ($wil) {
            case 'WIL1':
                $tabel = "absen_wil1";
                break;
            case 'WIL2':
                $tabel = "absen_wil2";
                break;
            case 'WIL3':
                $tabel = "absen_wil3";
                break;
            case 'WIL4':
                $tabel = "absen_wil4";
                break;
            default:
                break;
        }

        $presensiKemarin = $this->Anggota_model->absenKemarin($npk, $tgl_kemarin, $wil);
        $presensiSekarang = $this->Anggota_model->absenKemarin($npk, $now, $wil);

        if ($presensiSekarang->num_rows() > 0) {
            $absen = $presensiSekarang->row();
            if ($absen->validasi_kehadiran == 1 && $absen->ket == NULL) {
                $awal  = strtotime($absen->in_time . " " . $absen->in_date);
                $akhir = strtotime(date('Y-m-d H:i:s'));
                $diff  = $akhir - $awal;
                //jam selisih untuk absen pulang
                $jam   = floor($diff / (60 * 60));
                if ($jam <= 1) {
                    $this->response([
                        "status"     => "fail",
                        "info"       => "Absen Pulang" ,
                        "time"       =>  date('Y-m-d H:i:s') ,
                        "message"    => "Silahkan Absen di Jam Berikutnya"
                    ], 404);
                    // echo "anda bisa absen lagi 5 jam dari sekarang";
                } else {
                    //absen pulang
                    $data = [
                        'out_time'           => date('H:i:s'),
                        'out_date'           => date('Y-m-d'),
                        'validasi_kehadiran' => 2,
                        'ket'                => "HADIR"
                    ];
                    $this->db->where('id', $absen->id);
                    $this->db->update($tabel, $data);
                    $this->response([
                        "status"       => "success",
                        "message"       => "Absen Pulang Berhasil" ,
                        "time"          =>  date('Y-m-d H:i:s') ,
                        "info"          => "Absen Pulang" ,
                    ], 200);
                    // echo "anda absen pulang bos";
                }
            } else if ($absen->validasi_kehadiran == 2) {
                $awal  = strtotime($absen->out_time . " " . $absen->out_date);
                $akhir = strtotime(date('Y-m-d H:i:s'));
                $diff  = $akhir - $awal;

                //jam selisih untuk absen pulang
                $jam   = floor($diff / (60 * 60));

                //jika kurang dari 6jam maka tidak bisa absen pulang
                if ($jam < 6) {
                    $this->response([
                        "status"     => "fail",
                        "message"    =>  "Silahkan Absen di Jam Berikutnya " ,
                        "time"       => date('Y-m-d H:i:s') ,
                        "info"       => "Absen Masuk" ,
                    ], 200);
                    // echo "anda bisa absen lagi  6 jam dari sekarang";
                } else if ($jam > 6 || $jam <= 18) {
                    $data = [
                        'id_absen'  => $id_absen,
                        'npk'       => $npk,
                        'in_time'   => date('H:i:s'),
                        'in_date'   => date('Y-m-d'),
                        'area'      => $area,
                        'validasi_kehadiran' =>  1,
                        'ket'     => NULL
                    ];
                    $this->db->insert($tabel, $data);
                    $this->response([
                        "status"     => "success",
                        "message"    =>  "Absen Masuk Berhasil" ,
                        "time"       =>  date('Y-m-d H:i:s') ,
                        "info"       => "Absen Masuk" ,
                    ], 200);
                    // echo "anda bisa absen masuk lagi";
                }
            }
        } else {
            if ($presensiKemarin->num_rows() <= 0) {
                $data = [
                    'id_absen'              => $id_absen,
                    'npk'                   => $npk,
                    'in_time'               => date('H:i:s'),
                    'in_date'               => date('Y-m-d'),
                    'area'                  => $area,
                    'validasi_kehadiran'    =>  1
                ];
                $this->db->insert($tabel, $data);
                $this->response([
                    "status"        => "success",
                    "message"       =>  "Absen Masuk Berhasil" ,
                    "info"          => "Absen Masuk" ,
                    "time"          =>  date('Y-m-d H:i:s') ,
                ], 200);
                // echo "input absen baru disini";
            } else if ($presensiKemarin->num_rows() > 0) {
                $absen = $presensiKemarin->row();
                if ($absen->validasi_kehadiran == 1 && $absen->ket == NULL) {

                    //hitung count jam dari jam masuk sampai jam sekarang
                    $awal  = strtotime($absen->in_time . " " . $absen->in_date);
                    $akhir = strtotime(date('Y-m-d H:i:s'));
                    $diff  = $akhir - $awal;

                    //jam selisih untuk absen pulang
                    $jam   = floor($diff / (60 * 60));

                    //jika jam kurang dari 6jam maka absen pulang di tolak
                    if ($jam <= 4) {
                        $this->response([
                            "status"        =>  "fail",
                            "message"       =>  "Silahkan Absen di Jam Berikutnya" ,
                            "info"         =>  "Absen Pulang" ,
                            "time"          =>  date('Y-m-d H:i:s') ,
                        ], 200);
                        // echo "anda belum bisa absen pulang coy";
                    } else if ($jam >= 5 || $jam <= 18) {
                        //absen pulang
                        $data = [
                            'out_time'           => date('H:i:s'),
                            'out_date'           => date('Y-m-d'),
                            'validasi_kehadiran' => 2,
                            'ket'                => "HADIR"
                        ];
                        $this->db->where('id', $absen->id);
                        $this->db->update($tabel, $data);
                        $this->response([
                            "status"     => "success",
                            "message"   =>  "Absen Pulang Berhasil" ,
                            "info"       => "Absen Pulang",
                            "time"      => date('Y-m-d H:i:s') ,
                        ], 200);
                        // echo "anda bisa absen pulang";
                    }
                } else if ($absen->validasi_kehadiran == 2) {
                    $awal  = strtotime($absen->out_time . " " . $absen->out_date);
                    $akhir = strtotime(date('Y-m-d H:i:s'));
                    $diff  = $akhir - $awal;

                    //jam selisih untuk absen pulang
                    $jam   = floor($diff / (60 * 60));

                    //jika jam kurang dari 6jam maka absen masuk di tanggal sama  di tolak
                    if ($jam <= 1) {
                        $this->response([
                            "status"     => "fail",
                            "info"       => "Absen Masuk",
                            "message"    => "Silahkan Absen di Jam Berikutnya" ,
                            "time"       => date('Y-m-d H:i:s') ,
                        ], 404);
                        // echo "anda belum bisa absen masuk lagi";
                    } else if ($jam >= 2 || $jam <= 18) {
                        $data = [
                            'id_absen'           => $id_absen,
                            'npk'                => $npk,
                            'in_time'            => date('H:i:s'),
                            'in_date'            => date('Y-m-d'),
                            'area'               => $area,
                            'validasi_kehadiran' =>  1,
                            'ket'                => ""
                        ];
                        $this->db->insert($tabel, $data);
                        $this->response([
                            "status"     => "success",
                            "message"    => "Absen Masuk Berhasil" ,
                            "info"       => "Absen Masuk" ,
                            "time"       => date('Y-m-d H:i:s') ,
                        ], 200);
                        // echo "anda bisa absen masuk lagi di tanggal yang sama ";
                    }
                }
            }
        }
    }
    
    public function showAbsensi_get()
    {
        $t = new Grei\TanggalMerah();
        $bulan = date('02');
        $tahun = date('Y'); //Mengambil tahun saat ini
        // $bulan = date('m'); //Mengambil bulan saat ini
        $tanggal = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);
        $bln = $this->input->get("bulan");
        $npk = $this->input->get("npk");
        $wilayah  = $this->input->get('wilayah');
        switch($wilayah){
            case 'WIL1':
                $tabel = "absen_wil1";
                break;
            case 'WIL2':
                $tabel = "absen_wil2";
                break;
            case 'WIL3':
                $tabel = "absen_wil3";
                break;
            case 'WIL4':
                $tabel = "absen_wil4";
                break;
            default:
                break;
        }
        $sheet = $this->db->query('select  in_date , in_time , out_time , ket  from '. $tabel .' where npk = "'. $npk .'" and in_date like "%2022-' . $bln . '%" ');
        
        if($sheet->num_rows() > 0 ){
            $this->response([
                'status'   => 'success',
                'result'   =>  $sheet->result()
            ], 200);
        }else {
            $this->response([
                'status'     => 'failed',
                'result'      => 'not found'
            ], 404);
        }
    }
    
    
    // 
    public function getAbsenFull_get(){
        
        $t = new Grei\TanggalMerah();
        // $bulan = date('02'); //Mengambil tahun saat ini
        $tahun = date('Y'); //Mengambil tahun saat ini
        $bln = $this->input->get("bulan");
        $npk = $this->input->get("npk");
        $tanggal = cal_days_in_month(CAL_GREGORIAN, $bln, $tahun);
        $wilayah  = $this->input->get('wilayah');
        switch($wilayah){
            case 'WIL1':
                $tabel = "absen_wil1";
                break;
            case 'WIL2':
                $tabel = "absen_wil2";
                break;
            case 'WIL3':
                $tabel = "absen_wil3";
                break;
            case 'WIL4':
                $tabel = "absen_wil4";
                break;
            default:
                break;
        }
        $absen = array();
        for($i = 1 ; $i <= $tanggal ; $i++ ) {
            if($i <= 9 ){
                $i = "0" . $i ;
            }else {
                $i = $i ;
            }
            $time =  $tahun . "-" . $bln . "-" . $i ;
            $dt = $this->db->get_where($tabel , ['in_date' => $time , 'npk'  => $npk ]);
                
                if($dt->num_rows() > 0 ){
                    $data = $dt->row();
                     $d = [
                        'time'       => $time ,
                        'in_time'    => $data->in_time ,
                        'in_date'    => $data->in_date ,
                        'out_time'   => $data->out_time ,
                        'out_date'   => $data->out_date ,
                        'ket'        => $data->ket 
                    ];
                    array_push($absen , $d );
                }else {
                    $d = [
                        'time'       => $time ,
                        'in_time'    => "-" ,
                        'in_date'    =>"-",
                        'out_time'   =>"-" ,
                        'out_date'   =>"-" ,
                        'ket'        => "-"
                    ];
                    array_push($absen , $d );
                }
        }
        
        if(count($absen) > 0 ){
            $this->response([
                    'status'   => 'success',
                    'count'    => count($absen) ,
                    'result'   => $absen ,
            ], 200);
        }else {
            $this->response([
                'status'     => 'failed',
                'result'     => 'not found'
            ], 404);
        }
    }
    
    // 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
