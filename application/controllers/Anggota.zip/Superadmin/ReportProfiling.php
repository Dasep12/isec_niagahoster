<?php

require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ReportProfiling extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $role = $this->session->userdata('role_id');
      if(empty($role)){
        $this->session->userdata("logout","Sesi Berakhir");
        redirect('Login');
      }elseif($role != 9 ){
          redirect("LogOut");
      }    
  }

  function index()
  {     
        $filename = "Profiling" . date('Y-m-d');
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'REPORT PROFILING');
        $sheet->setCellValue('A2', 'I - SECURITY');
        $sheet->setCellValue('A3', date('Y-m-d'));

        $styleArray = [
            'font' => [
                'bold' => true,
            ],
            'alignment' => [
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => 'thin'],
            ],
            'color' => [
                'argb' => ['#f7df07'],
            ],
        ];
        $styleValue = [
            
            'alignment' => [
                'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            ],
            'borders' => [
                'allBorders' => ['borderStyle' => 'thin'],
            ],
            'color' => [
                'argb' => ['#f7df07'],
            ],
        ];
    
        $sheet->mergeCells('A6:A7');
        $sheet->mergeCells('B6:B7');
        $sheet->mergeCells('C6:C7');
        $sheet->mergeCells('D6:D7');
        $sheet->mergeCells('E6:E7');
        $sheet->mergeCells('F6:F7');
        $sheet->mergeCells('G6:G7');
        $sheet->mergeCells('H6:H7');
        $sheet->mergeCells('I6:I7');
        $sheet->mergeCells('J6:J7');
        $sheet->mergeCells('K6:K7');
        $sheet->mergeCells('L6:L7');
        $sheet->mergeCells('M6:M7');
        $sheet->mergeCells('N6:N7');
        $sheet->mergeCells('O6:U6');
        $sheet->mergeCells('V6:AB6');
        $sheet->mergeCells('AC6:AC7');
        $sheet->mergeCells('AD6:AD7');
        $sheet->mergeCells('AE6:AE7');
        $sheet->mergeCells('AF6:AF7');
        $sheet->mergeCells('AG6:AG7');
        $sheet->getStyle('A6:AG7')->applyFromArray($styleArray);
        $sheet->getStyle('A8:AG391')->applyFromArray($styleValue);
        $sheet->setCellValue('A6', 'NO');
        $sheet->setCellValue('B6', 'NAMA');
        $sheet->setCellValue('C6', 'WILAYAH');
        $sheet->setCellValue('D6', 'NPK');
        $sheet->setCellValue('E6', 'NAMA');
        $sheet->setCellValue('F6', 'NO KTP');
        $sheet->setCellValue('G6', 'NO KK');
        $sheet->setCellValue('H6', 'EMAIL');
        $sheet->setCellValue('I6', 'NO HANDPHONE');
        $sheet->setCellValue('J6', 'NO DARURAT');
        $sheet->setCellValue('K6', 'TINGGI BADAN');
        $sheet->setCellValue('L6', 'BERAT BADAN');
        $sheet->setCellValue('M6', 'NILAI IMT');
        $sheet->setCellValue('N6', 'KETERANG IMT');
        $sheet->setCellValue('O6', 'ALAMAT KTP');
        $sheet->setCellValue('V6', 'ALAMAT DOMISILI');
        $sheet->setCellValue('O7', 'ALAMAT');
        $sheet->setCellValue('P7', 'RT');
        $sheet->setCellValue('Q7', 'RW');
        $sheet->setCellValue('R7', 'KELURAHAN');
        $sheet->setCellValue('S7', 'KECAMATAN');
        $sheet->setCellValue('T7', 'KOTA/KABUPATEN');
        $sheet->setCellValue('U7', 'PROVINSI');
        $sheet->setCellValue('V7', 'ALAMAT');
        $sheet->setCellValue('W7', 'RT');
        $sheet->setCellValue('X7', 'RW');
        $sheet->setCellValue('Y7', 'KELURAHAN');
        $sheet->setCellValue('Z7', 'KECAMATAN');
        $sheet->setCellValue('AA7', 'KOTA/KABUPATEN');
        $sheet->setCellValue('AB7', 'PROVINSI');
        $sheet->setCellValue('AC6', 'NO REG KTA');
        $sheet->setCellValue('AD6', 'EXPIRED KTA');
        $sheet->setCellValue('AE6', 'JABATAN');
        $sheet->setCellValue('AF6', 'STATUS KTA');
        $sheet->setCellValue('AG6', 'FOTO PROFIL');


         $export = $this->Super_model->ExportProfiling();
		// echo '<pre>';
        // var_dump($export);
        
        	$no = 1;
			$x = 8;
			foreach($export as $row)
			{
				$sheet->setCellValue('A'.$x, $no++);
				$sheet->setCellValue('B'.$x, $row->area_kerja);
				$sheet->setCellValue('C'.$x, $row->wilayah);
				$sheet->setCellValue('D'.$x, $row->npk);
				$sheet->setCellValue('E'.$x, $row->nama);
				$sheet->setCellValue('F'.$x, $row->ktp);
				$sheet->setCellValue('G'.$x, $row->kk);
				$sheet->setCellValue('H'.$x, $row->email);
				$sheet->setCellValue('I'.$x, $row->no_hp);
				$sheet->setCellValue('J'.$x, $row->no_emergency);
				$sheet->setCellValue('K'.$x, $row->tinggi_badan);
				$sheet->setCellValue('L'.$x, $row->berat_badan);
				$sheet->setCellValue('M'.$x, $row->imt);
				$sheet->setCellValue('N'.$x, $row->keterangan);
				$sheet->setCellValue('O'.$x, $row->jl_ktp);
				$sheet->setCellValue('P'.$x, $row->rt_ktp);
				$sheet->setCellValue('Q'.$x, $row->rw_ktp);
				$sheet->setCellValue('R'.$x, $row->kel_ktp);
				$sheet->setCellValue('S'.$x, $row->kec_ktp);
				$sheet->setCellValue('T'.$x, $row->kota_ktp);
				$sheet->setCellValue('U'.$x, $row->provinsi_ktp);
				$sheet->setCellValue('V'.$x, $row->jl_dom);
				$sheet->setCellValue('W'.$x, $row->rt_dom);
				$sheet->setCellValue('X'.$x, $row->rw_dom);
				$sheet->setCellValue('Y'.$x, $row->kel_dom);
				$sheet->setCellValue('Z'.$x, $row->kec_dom);
				$sheet->setCellValue('AA'.$x, $row->kota_dom);
				$sheet->setCellValue('AB'.$x, $row->provinsi_dom);
				$sheet->setCellValue('AC'.$x, $row->no_kta);
				$sheet->setCellValue('AD'.$x, $row->expired_kta);
				$sheet->setCellValue('AE'.$x, $row->jabatan);
				$sheet->setCellValue('AF'.$x, $row->status_kta);
				$sheet->setCellValue('AG'.$x, $row->foto);
				

				$x++;
			}

        $writer = new Xlsx($spreadsheet);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');
        $writer->save('php://output');
  }


}


?>